#!/bin/bash
mkdir -p tmp/fl/mamdani/matlab
mkdir -p tmp/fl/mamdani/octave
mkdir -p tmp/fl/takagi-sugeno/matlab
mkdir -p tmp/fl/takagi-sugeno/octave
mkdir -p tmp/fl/tsukamoto
