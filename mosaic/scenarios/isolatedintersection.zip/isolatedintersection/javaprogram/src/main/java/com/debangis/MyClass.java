package com.debangis;

public class MyClass{


	public String ReturnString(){
		return "I was returned from MyClass";	
	}
}